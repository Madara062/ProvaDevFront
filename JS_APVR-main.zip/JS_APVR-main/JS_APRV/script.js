document.addEventListener('DOMContentLoaded', () => {
  const converterBtn = document.getElementById('converter-btn');
  const valorInput = document.getElementById('valor');
  const deMoeda = document.getElementById('moeda-origem'); 
  const paraMoeda = document.getElementById('moeda-destino'); 
  const resultadoDiv = document.getElementById('resultado');
  const erroDiv = document.getElementById('erro-mensagem');

  const taxasDeCambio = {
    'BRL-USD': 0.19,
    'BRL-EUR': 0.18,
    'USD-BRL': 5.26,
    'USD-EUR': 0.92,
    'EUR-BRL': 5.74,
    'EUR-USD': 1.09
  };

  converterBtn.addEventListener('click', () => {
    resultadoDiv.textContent = '';
    erroDiv.textContent = '';

    const valor = parseFloat(valorInput.value);
    const de = deMoeda.value;
    const para = paraMoeda.value;

    if (isNaN(valor) || valor <= 0) {
      erroDiv.textContent = 'Por favor, insira um valor válido maior que zero.';
      return;
    }

    if (de === para) {
      erroDiv.textContent = 'As moedas de origem e destino devem ser diferentes.';
      return;
    }

    const chave = `${de}-${para}`;
    const taxa = taxasDeCambio[chave];

    if (taxa) {
      const resultado = (valor * taxa).toFixed(2);
      resultadoDiv.textContent = `${valor} ${de} = ${resultado} ${para}`;
    } else {
      erroDiv.textContent = 'Conversão não disponível para essa combinação de moedas.';
    }
  });
});
