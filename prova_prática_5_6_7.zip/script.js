document.addEventListener('DOMContentLoaded', () => {
    const inputNovaTarefa = document.getElementById('nova-tarefa');
    const btnAdicionar = document.getElementById('btn-adicionar');
    const listaTarefas = document.getElementById('tarefas');
    const divErro = document.getElementById('erro');

    // Adicionar tarefa ao clicar no botão
    btnAdicionar.addEventListener('click', adicionarTarefa);

    // Adicionar tarefa ao pressionar Enter
    inputNovaTarefa.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            adicionarTarefa();
        }
    });

    function adicionarTarefa() {
        const texto = inputNovaTarefa.value.trim();
        
        // Verificar se o texto está vazio
        if (texto === '') {
            divErro.textContent = 'Por favor, digite uma tarefa.';
            divErro.style.display = 'block';
            return;
        }
        
        // Limpar mensagem de erro
        divErro.style.display = 'none';
        
        // Criar novo item de lista
        const novoItem = document.createElement('li');
        
        // Criar span para o texto da tarefa
        const spanTarefa = document.createElement('span');
        spanTarefa.textContent = texto;
        spanTarefa.className = 'tarefa-texto';
        
        // Criar div para os botões de ação
        const divAcoes = document.createElement('div');
        divAcoes.className = 'acoes';
        
        // Criar botão Concluir
        const btnConcluir = document.createElement('button');
        btnConcluir.textContent = 'Concluir';
        btnConcluir.className = 'btn-concluir';
        
        // Criar botão Remover
        const btnRemover = document.createElement('button');
        btnRemover.textContent = 'Remover';
        btnRemover.className = 'btn-remover';
        
        // Adicionar eventos aos botões
        btnConcluir.addEventListener('click', () => {
            spanTarefa.classList.toggle('concluida');
        });
        
        btnRemover.addEventListener('click', () => {
            novoItem.remove();
        });
        
        // Montar a estrutura do item
        divAcoes.appendChild(btnConcluir);
        divAcoes.appendChild(btnRemover);
        novoItem.appendChild(spanTarefa);
        novoItem.appendChild(divAcoes);
        
        // Adicionar à lista
        listaTarefas.appendChild(novoItem);
        
        // Limpar o campo de entrada
        inputNovaTarefa.value = '';
    }
});